# Belangrijk
je moet onder @start in je SSD op een lijn "autonumber" zetten, dan nummert hij de berichten in volgorde.