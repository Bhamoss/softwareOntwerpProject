[Link naar SD documentatie](http://plantuml.com/sequence-diagram "Official sequence diagram quick start.")  
Noteer commentaar op elkaar met
het volgende formaat op de lijn net
na de message waar je commentaar op hebt:  
```
note left  
    commentaar  
end note
```
Je kunt ook right zetten in plaats van left
om je commentaar rechts van de SSD te plaatsen.

## Use Case: Edit Column Characteristics

We moeten toch nog eens praten denken over die preconditions.  

Ik heb de alternative use cases een eigen SSD gegeven.
Ze waren te groot en los van elkaar, plus ze wijken af al van stap 1, da is basically een aparte use case.

