This directory contains UML diagrams that describe the system.

Make the diagrams with the following code:  
`plantuml -tsvg path/to/diagram.puml -o path/to/output/directory`  
