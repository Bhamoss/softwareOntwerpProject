package tablr;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TableHandlerTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getNbTables() {
    }

    @Test
    void getTableNames() {
    }

    @Test
    void canHaveAsName() {
    }

    @Test
    void getOpenTable() {
    }

    @Test
    void setTableName() {
    }

    @Test
    void addTable() {
    }

    @Test
    void removeTable() {
    }

    @Test
    void openTable() {
    }

    @Test
    void isTerminated() {
    }

    @Test
    void createTableDesignHandler() {
    }

    @Test
    void createTableRowsHandler() {
    }
}