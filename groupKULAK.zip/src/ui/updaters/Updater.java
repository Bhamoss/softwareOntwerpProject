package ui.updaters;

public abstract class Updater {
    abstract public void update();
}
