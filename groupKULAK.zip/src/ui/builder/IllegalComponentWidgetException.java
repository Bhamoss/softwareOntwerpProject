package ui.builder;

public class IllegalComponentWidgetException extends RuntimeException{

}
