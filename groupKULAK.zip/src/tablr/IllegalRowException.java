package tablr;

public class IllegalRowException extends RuntimeException{
}
