package tablr;

public class IllegalColumnException extends RuntimeException{
}
