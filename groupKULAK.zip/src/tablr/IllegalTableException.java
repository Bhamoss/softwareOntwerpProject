package tablr;

public class IllegalTableException extends RuntimeException{
}
