package tablr;

public class IllegalTypeException extends RuntimeException {
}
