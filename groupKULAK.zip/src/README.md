This directory contains the source code of the system.  

Doe het volgende om javadoc te genereren zodat ook de @resp tag wordt gerespecteerd:
1) Tools --> Generate JavaDoc...
2) Vink het volgende aan:  
    - Whole project
    - Include test sources 
    - Open generated documentation in browser
3) Doe de slider naar private.
4) Zet de output directory op onze  
softwareOntwerpProject/doc
5) vul het volgende in bij *Other command line arguments*:  
-tag resp:a:"Responsibility:"

6) Druk op oke