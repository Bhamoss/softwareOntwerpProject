package tablr;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TableDesignHandlerTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getColumnNames() {
    }

    @Test
    void getOpenTable() {
    }

    @Test
    void getColumnType() {
    }

    @Test
    void getColumnAllowBlank() {
    }

    @Test
    void getColumnDefaultValue() {
    }

    @Test
    void canHaveAsColumnName() {
    }

    @Test
    void canHaveAsColumnType() {
    }

    @Test
    void canHaveAsColumnAllowBlanks() {
    }

    @Test
    void canHaveAsDefaultValue() {
    }

    @Test
    void setColumnName() {
    }

    @Test
    void setColumnType() {
    }

    @Test
    void setColumnAllowBlanks() {
    }

    @Test
    void setColumnDefaultValue() {
    }

    @Test
    void addColumn() {
    }

    @Test
    void removeColumn() {
    }

    @Test
    void isTerminated() {
    }
}