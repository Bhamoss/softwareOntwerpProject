# Software engeneering project - final version
Door Michiel Provoost, Michiel Jonckheere, Thomas Bamelis, Jaron Maene

Contents:
- system.jar (gebruik java-8, java-11 zal crashen)
- src        (broncode)
- diagrams   (plantuml beschrijving van design)
- doc        (javadoc van de src)
- test	     (tests in junit)

Notes:
- tests zijn gemaakt op ubuntu. Door de limitaties van windowRecording is dit portable, en zal dit dus niet runnen op windows.
- voor een actie ongedaan te maken is ctrl-y gebruikt i.p.v ctrl-shift-z
